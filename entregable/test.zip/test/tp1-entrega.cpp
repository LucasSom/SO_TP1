#include "grafo.h"
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include <limits>
#include <mutex>
#include <queue>
#include <utility>
#include <semaphore.h>
#include <unistd.h>
#include <atomic>
#include <assert.h>
#include <chrono>

using namespace std;

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
//////////////// DATOS DEL SECUENCIAL ///////////////////////////
/////////////////////////////////////////////////////////////////

#define BLANCO -10
#define GRIS -20
#define NEGRO -30
#define SHARED_SEM 1
#define NADIE -2

//COLORES de los nodos
vector<int> colores;

//DISTANCIA mínima del nodo al árbol
vector<int> distancia;
vector<int> distanciaNodo;

/* MAXIMO VALOR DE INT */
int IMAX = numeric_limits<int>::max();


/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
//////////////// DATOS DEL PARALELO /////////////////////////////
/////////////////////////////////////////////////////////////////


//el colores usamos el secuencial que total tenemos un solo arbol compartido
//el IMAX usamos el secuencial

//DISTANCIA mínima del nodo al árbol.
//distancia[i] = vector con todas las dists al arbol del thread i
vector<vector <int> > distanciaParal;
vector<vector <int> > distanciaNodoParal;
// Colores de los nodos para arbol del thread i
vector<vector <int> > coloresArbol;
vector<pair <mutex, int> >* conQuienMergeo;
mutex conQuienMergeoPermiso;

//Logica de mergeStruct

typedef struct mergeStruct {
  int tidDelQuePide;
  int nodoFusion;
  bool esPrimerNodo;
  sem_t semDeCola;
  sem_t semDePedidor;

} mergeStruct;


class Spinlock{
  std::atomic_flag flag;
public:
  Spinlock(): flag(ATOMIC_FLAG_INIT) {}

  void lock(){
    while( flag.test_and_set() );
  }

  void unlock(){
    flag.clear();
  }
};

//colasEspera[i] es la cola en la que el thread i ve si alguien pidió un merge
//colasEspera[i] también tiene un mutex para que la cola no se rompa por la concurrencia
vector< pair<Spinlock, queue<mergeStruct*> > >* colasEspera;

//para modificar el nodo i del grafo compartido hay que pedir permiso
//al mutex permisoNodo[i]
//es un puntero al vector para poder tener tamaño dinámico sin copiar mutexes
vector<mutex>* permisoNodo;
//el arbol resultado que solo modifica el thread que no le quedan
//nodos que agregar (o sea que es el último)
// arbolRta para devolver resultado en paralelo
// grafoCompartido grafo original
Grafo* arbolRta;
Grafo* grafoCompartido;
atomic <int> threadsVivos;
vector<Grafo> arbolesGenerados;
int nroThreads;
typedef struct inputThread {
  int threadId;
  int nodoInicialRandom;

} inputThread;



/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////



//Pinto el nodo de negro para marcar que fue puesto en el árbol
void pintarNodo(int num){
  colores[num] = NEGRO;
  //Para no volver a elegirlo
  distancia[num] = IMAX;
}

//Pinto los vecinos de gris para marcar que son alcanzables desde el árbol (salvo los que ya son del árbol)
void pintarVecinos(Grafo *g, int num){
  for(vector<Eje>::iterator v = g->vecinosBegin(num); v != g->vecinosEnd(num); ++v){
	//Es la primera vez que descubro el nodo
	if(colores[v->nodoDestino] == BLANCO){
		//Lo marco como accesible
		colores[v->nodoDestino] = GRIS;
		//Le pongo el peso desde donde lo puedo acceder
		distancia[v->nodoDestino] = v->peso;
		//Guardo que nodo me garantiza esa distancia
		distanciaNodo[v->nodoDestino] = num;
	}else if(colores[v->nodoDestino] == GRIS){
		//Si ya era accesible, veo si encontré un camino más corto
		distancia[v->nodoDestino] = min(v->peso,distancia[v->nodoDestino]);
		//Guardo que nodo me garantiza esa distancia
		if(distancia[v->nodoDestino] == v->peso)
		distanciaNodo[v->nodoDestino] = num;
	}
  }
}

double mstSecuencial(Grafo *g){
  //Semilla random
  srand(time(0));
  //Arbol resultado
  Grafo arbol;
  //Por ahora no colorié ninguno de los nodos
  colores.assign(g->numVertices,BLANCO);
  //Por ahora no calculé ninguna distancia
  distancia.assign(g->numVertices,IMAX);
  distanciaNodo.assign(g->numVertices,-1);

  //Selecciono un nodo al azar del grafo para empezar
  int nodoActual = rand() % g->numVertices;
  for(int i = 0; i < g->numVertices; i++){
	arbol.numVertices += 1;

	//La primera vez no lo agrego porque necesito dos nodos para unir
	if(i > 0){
	  arbol.insertarEje(nodoActual,distanciaNodo[nodoActual],distancia[nodoActual]);
	}

	//Lo pinto de NEGRO para marcar que lo agregué al árbol y borro la distancia
	pintarNodo(nodoActual);

	//Descubrir vecinos: los pinto y calculo distancias
	pintarVecinos(g,nodoActual);

	//Busco el nodo más cercano que no esté en el árbol, pero sea alcanzable
	nodoActual = min_element(distancia.begin(),distancia.end()) - distancia.begin();
  }
  //arbol.imprimirGrafo();
  return arbol.pesoTotal();
}

/////////////////////////////////////////////////////////////////7
//////////////////////////////////////////////////////////////////
//////////////////NUESTRO CODIGO//////////////////////////////////
/////////////////////////////////////////////////////////////////

//Pinto el nodo de (-i) para marcar que fue puesto en el árbol i
void pintarNodoPararelo(int nodo, int miTid){
	colores[nodo] = miTid;
	coloresArbol[miTid][nodo] = NEGRO;
	//Para no volver a elegirlo (desde el thread i)
	distanciaParal[miTid][nodo] = IMAX;
}

void pintarNodoParareloAux(int nodo, int miTid){
	colores[nodo] = miTid;
	coloresArbol[miTid][nodo] = NEGRO;
}

void pintarVecinosParalelo(Grafo *miArbol, int num, int miTid){
  for(vector<Eje>::iterator v = grafoCompartido->vecinosBegin(num); v != grafoCompartido->vecinosEnd(num); ++v){
	//Es la primera vez que descubro el nodo
	if(coloresArbol[miTid][v->nodoDestino] == BLANCO){
		//Lo marco como accesible
		coloresArbol[miTid][v->nodoDestino] = GRIS;
		//Le pongo el peso desde donde lo puedo acceder
		distanciaParal[miTid][v->nodoDestino] = v->peso;
		//Guardo que nodo me garantiza esa distancia
		distanciaNodoParal[miTid][v->nodoDestino] = num;
	}else if(coloresArbol[miTid][v->nodoDestino] == GRIS){
		//Si ya era accesible, veo si encontré un camino más corto
		distanciaParal[miTid][v->nodoDestino] = min(v->peso,distanciaParal[miTid][v->nodoDestino]);
		//Guardo que nodo me garantiza esa distancia
		if(distanciaParal[miTid][v->nodoDestino] == v->peso)
		distanciaNodoParal[miTid][v->nodoDestino] = num;
	}
  }
}

void actualizarLogicaColores(int miTid, int tidAMorir){

	for (int nodo = 0; nodo < coloresArbol[miTid].size(); ++nodo){
		if(coloresArbol[miTid][nodo] != NEGRO){
			if (coloresArbol[tidAMorir][nodo] == NEGRO){
				/*En aMorir es negro pero en el original no.
				Entonces, tengo que pintarlo de negro y actualizar la distancia
				estos van a ser los nodos que agregamos antes del arbolAMorir al arbol que vive*/
				distanciaParal[miTid][nodo] = distanciaParal[tidAMorir][nodo];//distancia va a ser IMAX
				distanciaNodoParal[miTid][nodo] = distanciaNodoParal[tidAMorir][nodo];
				coloresArbol[miTid][nodo] = NEGRO;

				permisoNodo->operator[](nodo).lock();
				colores[nodo] = miTid;
				permisoNodo->operator[](nodo).unlock();
			}else{//ambos son blancos o grises
				if (coloresArbol[tidAMorir][nodo] == GRIS){
					if (coloresArbol[miTid][nodo] == GRIS){
						/* Ambos son grises. Voy a querer guardar la menor distancia
						para que luego se use la distancia efectivamente menor*/
						if (distanciaParal[miTid][nodo] > distanciaParal[tidAMorir][nodo]){
							distanciaParal[miTid][nodo] = distanciaParal[tidAMorir][nodo];
							distanciaNodoParal[miTid][nodo] = distanciaNodoParal[tidAMorir][nodo];
							//Ya esta de gris, no tengo que actualizar el color
						}//ELSE: dejo como estaba (si ya tenía la distancia menor)
					}else{
						/*En el original es blanco, y en el aMorir, gris*/
						distanciaParal[miTid][nodo] = distanciaParal[tidAMorir][nodo];
						distanciaNodoParal[miTid][nodo] = distanciaNodoParal[tidAMorir][nodo];
						coloresArbol[miTid][nodo] = GRIS;
					}
				}//ELSE: si el nodo en el arbol de aMorir es blanco, dejo lo que esta
			}
		}//ELSE: si el nodo en el arbol del thread que vive es negro, no tengo que hacer nada
			//(porque ese nodo ya está incluído en el arbol que sobrevive)
	}

}

void sumar_arbol(int tidDelQuePide, int tidCola, int nodoActual, bool esPrimerNodo){
	int tidAMorir, miTid;
	Grafo* original;
	Grafo* aMorir;
	if (tidDelQuePide < tidCola){
		miTid = tidDelQuePide;
		tidAMorir = tidCola;
	}else{
		miTid = tidCola;
		tidAMorir = tidDelQuePide;
	}
	original = &arbolesGenerados[miTid];
	aMorir = &arbolesGenerados[tidAMorir];

	//al arbol privado del thread que va a sobrevivir le agregamos todos los ejes y nodos
	//del arbol privado que va a morir. Como hasta ahora no compartían nodos sabemos que los
	//arboles son disjuntos entonces simplemente agregamos todo
	for (map<int,vector<Eje>>::iterator nodo_ptr = aMorir->listaDeAdyacencias.begin(); nodo_ptr != aMorir->listaDeAdyacencias.end(); ++nodo_ptr){
		//recorre todos los nodos del arbol aMorir
		for (vector<Eje>::iterator it = aMorir->vecinosBegin(nodo_ptr->first); it != aMorir->vecinosEnd(nodo_ptr->first); ++it){	
			//recorre los ejes de cada nodo
			if (nodo_ptr->first < it->nodoDestino){
			//para evitar push_backear dos veces cada eje, solo inserto al menor
				original->insertarEje(nodo_ptr->first, it->nodoDestino, it->peso);
			}
		}
	}
	original->numVertices += aMorir->numVertices;

	if (!esPrimerNodo){
		original->insertarEje(nodoActual,distanciaNodoParal[tidDelQuePide][nodoActual],distanciaParal[tidDelQuePide][nodoActual]);
	}

	//cada thread tiene su vector de colores (BLANCO,GRIS,NEGRO) para saber cuales distancias ya calculo
	//como el secuencial. Copiamos todos los colores y distancias del thread que muere al otro
	actualizarLogicaColores(miTid, tidAMorir);

	//ahora copiamos la cola de espera del thread que va a morir, por si tenía 
	//a alguien esperando para mergearse, se lo pasa al que se lo comió

	colasEspera->operator[](tidAMorir).first.lock();
	colasEspera->operator[](miTid).first.lock();
	while (! colasEspera->operator[](tidAMorir).second.empty()){
		mergeStruct* encolado = colasEspera->operator[](tidAMorir).second.front();
		colasEspera->operator[](tidAMorir).second.pop();
		conQuienMergeo->operator[](encolado->tidDelQuePide).first.lock();
		conQuienMergeo->operator[](encolado->tidDelQuePide).second = miTid;
		conQuienMergeo->operator[](encolado->tidDelQuePide).first.unlock();

		colasEspera->operator[](miTid).second.push(encolado);
	}		
	colasEspera->operator[](tidAMorir).first.unlock();
	colasEspera->operator[](miTid).first.unlock();
	//desbloqueamos esto aunque en teoría nunca lo volvamos a usar
}

bool chequeoCircular(int miTid, int otroThread){
	//inicializo booleanos en false
	bool visitados[nroThreads] = {0};
	bool termine = false;
	int esCasoCircular = false;
	visitados[miTid] = true;

	while (otroThread != NADIE and !termine){
		int temp = otroThread;
		if (visitados[temp]){
			// si ya lo visite, hay un ciclo
			if (temp == miTid)
				esCasoCircular = true; // volvi a mi mismo. Yo creo el ciclo
			termine = true;
		}else{
			//lo marco como visitado
			visitados[temp] = true;
			//navego entre pedidores
			conQuienMergeo->operator[](temp).first.lock();
			otroThread = conQuienMergeo->operator[](temp).second;
			conQuienMergeo->operator[](temp).first.unlock();
		}
	}
	//si llegue a nadie tampoco hay caso circular 
	return esCasoCircular;
}

bool chequeoColaPorPedidos(int miTid, int tidQueBusco){
	bool pudeMergearConTid = false;
	colasEspera->operator[](miTid).first.lock();
	while(!(colasEspera->operator[](miTid).second.empty())){
		//si tengo algo en la cola me mergeo
		//agarro los dos mutex que me pasó el primer thread con el que me voy a mergear (y su tid)
		mergeStruct* rendezvousP = colasEspera->operator[](miTid).second.front(); 
		colasEspera->operator[](miTid).second.pop();
		colasEspera->operator[](miTid).first.unlock();
		int tidDelQuePide = rendezvousP->tidDelQuePide;

		//me fijo si encontre el tid pasado por parametro
		if (tidDelQuePide == tidQueBusco) pudeMergearConTid = true;
		//hago rendezvous para que el otro thread (o yo) no muera hasta que me mergee con el
		sem_post(&rendezvousP->semDeCola);
		sem_wait(&rendezvousP->semDePedidor);
		//llamo a merge
		sumar_arbol(tidDelQuePide, miTid, rendezvousP->nodoFusion, rendezvousP->esPrimerNodo);
		sem_wait(&rendezvousP->semDePedidor);
		sem_post(&rendezvousP->semDeCola);
		//tidDelQuePide es el Tid del thread que se unió conmigo
		if(tidDelQuePide < miTid){
			//en este caso muero
			threadsVivos--;
			pthread_exit(NULL);
		}
		colasEspera->operator[](miTid).first.lock();
	}
	colasEspera->operator[](miTid).first.unlock();
	return pudeMergearConTid;
}

void *ThreadCicle(void* inThread){

	//cada thread tiene su input con tu Tid y su nodo inicial
	inputThread input = *((inputThread *) inThread);

	//agarro el nodo ya elegido al azar que me pasaron
	int nodoActual = input.nodoInicialRandom;
	int miTid = input.threadId;

	//Arbol propio
	Grafo* arbolMio = &(arbolesGenerados[miTid]);

	for(int i = 0; arbolMio->numVertices < grafoCompartido->numVertices; i++){
		// Me aseguro que nadie esté tocando este nodo compartido

		permisoNodo->operator[](nodoActual).lock();
		// Si ya estaba pintado me mergeo
		if(colores[nodoActual]!=BLANCO){
			int otroThread = colores[nodoActual];

			// Sección crítica donde se chequea si se generan ciclos si soy pedidor.
			conQuienMergeoPermiso.lock();
			bool esCasoCircular = chequeoCircular(miTid, otroThread);
			// Actualizo que pedi merge a otroThread. 
			conQuienMergeo->operator[](miTid).first.lock();
			conQuienMergeo->operator[](miTid).second = otroThread;
			conQuienMergeo->operator[](miTid).first.unlock();
			conQuienMergeoPermiso.unlock();

			if(!esCasoCircular){
				mergeStruct* rendezvous = new mergeStruct;
				rendezvous->tidDelQuePide = miTid;
				rendezvous->nodoFusion = nodoActual;
				// Si es la primera iteracion, no pinte ningun nodo
				rendezvous->esPrimerNodo = i == 0;

				//Inicializamos los semaforos en 0
				sem_init(&rendezvous->semDeCola, SHARED_SEM, 0);
				sem_init(&rendezvous->semDePedidor, SHARED_SEM, 0);

				// Le aviso al otroThread que estoy esperando para mergearme
				colasEspera->operator[](otroThread).first.lock();
				colasEspera->operator[](otroThread).second.push(rendezvous);			
				colasEspera->operator[](otroThread).first.unlock();

				// Ahora que ya le dije al thread que me quiero mergear, suelto el nodo del grafo compartido
				permisoNodo->operator[](nodoActual).unlock();

				sem_post(&rendezvous->semDePedidor);
				sem_wait(&rendezvous->semDeCola);
				
				sem_post(&rendezvous->semDePedidor);
				sem_wait(&rendezvous->semDeCola);
				// Destruyo semaforos
				sem_destroy(&rendezvous->semDePedidor);
				sem_destroy(&rendezvous->semDeCola);

				// Me fijo con quien me mergee finalmente para ver si muero
				conQuienMergeo->operator[](miTid).first.lock();
				otroThread = conQuienMergeo->operator[](miTid).second;
				conQuienMergeo->operator[](miTid).first.unlock();

				// Libero memoria pedida del rendez-vous
				delete rendezvous;
				if (otroThread < miTid){
					threadsVivos--;
					pthread_exit(NULL);
				}
			}else{
				// Como es caso circular, si me pusheo genero deadlock. Por eso me quedo esperando a que el otroThread se pushee a mi cola
				// Libero permiso nodo
				permisoNodo->operator[](nodoActual).unlock();
				bool seEncolo = false;
				while(!seEncolo){
					seEncolo = chequeoColaPorPedidos(miTid, otroThread);
				}				
			}

		}else{	
			//este camino es si todo sale bien como el secuencial
			//Lo pinto de NEGRO para marcar que lo agregué al árbol y borro la distancia
			pintarNodoParareloAux(nodoActual, miTid);			
			permisoNodo->operator[](nodoActual).unlock();

			arbolMio->numVertices += 1;
			//La primera vez no lo agrego porque necesito dos nodos para unir
			if(i > 0){
				arbolMio->insertarEje(nodoActual,distanciaNodoParal[miTid][nodoActual],distanciaParal[miTid][nodoActual]);
			}

			distanciaParal[miTid][nodoActual] = IMAX;
			
			//Descubrir vecinos: los pinto y calculo distancias
			pintarVecinosParalelo(arbolMio,nodoActual, miTid);
		}
		//el thread "miTid" chequea su cola a ver si alguien se quiere mergear,  no importa lo que devuelve chequeoColaPorPedidos
		chequeoColaPorPedidos(miTid, 0);

		//tanto si mergee como si no, tengo que buscar el prox nodoActual
		//Busco el nodo más cercano que no esté en el árbol, pero sea alcanzable
		nodoActual = min_element(distanciaParal[miTid].begin(),distanciaParal[miTid].end()) - distanciaParal[miTid].begin();
	}

	// Si llegue aca, es el resultado. Podrian haber threads vivos esperando mergearse conmigo o con otros.
	while(threadsVivos > 1){
		chequeoColaPorPedidos(miTid, 0);
	}
	arbolRta = arbolMio;
	pthread_exit(NULL);
}

int mstParalelo(Grafo *g, int cantThreads) {
	//Semilla random
	srand(time(0));

	// Arreglo para crear threads
	pthread_t thread[cantThreads];
	// Mutexeses para pintar nodos de a uno
	vector<mutex> mutexeses(g->numVertices);
	permisoNodo = &mutexeses;
	grafoCompartido = g;
	threadsVivos = cantThreads;
	nroThreads = cantThreads;

	//Cola de pedidos de merge
	vector<pair<Spinlock, queue<mergeStruct*> > > mutexesesCola(cantThreads);
	colasEspera = &mutexesesCola;

	//arreglo para saber si el thread i pidio merge con alguien
	vector<pair <mutex, int> > conQuienMergeoAux(cantThreads);
	for (int i = 0; i < cantThreads; ++i){
		conQuienMergeoAux[i].second = NADIE;
	}
	conQuienMergeo = &conQuienMergeoAux;

	//Por ahora no colorié ninguno de los nodos
	colores.assign(g->numVertices,BLANCO);
	coloresArbol.assign(cantThreads, vector<int>(g->numVertices,BLANCO));
	//Por ahora no calculé ninguna distancia
	//en distancia[i] tengo vector de todas las dists al arbol i
	distanciaParal.assign(cantThreads, vector<int>(g->numVertices,IMAX));
	distanciaNodoParal.assign(cantThreads, vector<int>(g->numVertices,-1));

	//estas son las structs que le pasamos a cada thread
	vector<inputThread> inputs(cantThreads);

	//sabemos que queremos un arbol para que genere cada thread
	arbolesGenerados.assign(cantThreads, Grafo());
	//LANZAR LOS THREADS
	for (int tid = 0; tid < cantThreads; ++tid){

		//le pasamos a cada thread su numero de hijo (no el que le asigno el SO, sino el nuestro)
		inputs[tid].threadId = tid;
		inputs[tid].nodoInicialRandom = rand() % g->numVertices;

        pthread_create(&thread[tid], NULL, &ThreadCicle, &(inputs[tid]));

    }

	//ESPERAR A QUE LOS THREADS MUERAN
    for (int x = 0; x < cantThreads; ++x){
        pthread_join(thread[x], NULL);
    }

	//podríamos agregar que imprima el tiempo que tardó para medirlo,
	//o que lo guarde en algún archivo junto con el tamaño del grafo
	//y cosas así

	//el último thread que queda lo sabe porque no le quedan nodos que agregar
	// guarda su arbol en un arbolRta compartido
 	//arbolRta->imprimirGrafo();
 	return arbolRta->pesoTotal();
}

/////////////////////////////////////////////////////////////////7
//////////////////////////////////////////////////////////////////
//////////////////NUESTRO CODIGO//////////////////////////////////
/////////////////////////////////////////////////////////////////

int main(int argc, char const * argv[]) {

  if(argc <= 2){
	cerr << "Ingrese nombre de archivo y cantidad de threads" << endl;
	return 0;
  }

  string nombre;
  nombre = string(argv[1]);
  string version = string(argv[2]);
  int cantThreads = atoi(argv[3]);

  Grafo g;

	if( g.inicializar(nombre) == 1){

		int pesoParalelo, pesoSecuencial, pesoFinal;
		bool test = false;

		if (version != "s"){//corremos el paralelo
  			pesoParalelo = mstParalelo(&g, cantThreads);
  			pesoFinal = pesoParalelo;
		}
		if (version != "p") {//corremos el secuencial
	  		pesoSecuencial = mstSecuencial(&g);
	  		pesoFinal = pesoSecuencial;
		}

		if (version == "a"){//se corrieron ambos
			/* comparamos sus resultados */
			test = (pesoSecuencial==pesoParalelo);
		}else{
			if (nombre=="simple.txt"){
				test = (pesoFinal==29);
			}else if (nombre=="complejo.txt"){
				test = (pesoFinal==19);
			}else if (nombre=="trivial.txt"){
				test = (pesoFinal==3);
			}
		}

		cout<<"Test con "<<nombre<<endl;
		if (version != "s"){
			cout<<"Cantidad de threads: "<<cantThreads<<endl;
		}
		if (test){
			cout<<"Result: [OK]"<<endl;
		}else{
			cout<<"Result: [FAILED]"<<endl;
		}
		cout<<endl;
		
	  }else{
		cerr << "No se pudo cargar el grafo correctamente" << endl;
	  }

  return 0;
}





